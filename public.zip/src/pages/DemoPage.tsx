import React from 'react';
import { PluginContainer } from '../components/PluginContainer/PluginContainer';
import { pluginRegistry } from '../plugins/registry';
import { PluginSettings } from '../components/PluginSettings/PluginSettings';

export const DemoPage: React.FC = () => {
    return (
        <div className="container mx-auto p-4">
            <h1 className="text-2xl font-bold mb-6">Plugin System Demo</h1>
            
            {/* Plugin Sections */}
            <div className="grid gap-6">
                <section>
                    <h2 className="text-xl font-semibold mb-3">Header Plugins</h2>
                    <PluginContainer 
                        section="header" 
                        plugins={pluginRegistry.getPluginsBySection('header')}
                    />
                </section>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <section className="col-span-1">
                        <h2 className="text-xl font-semibold mb-3">Sidebar Plugins</h2>
                        <PluginContainer 
                            section="sidebar" 
                            plugins={pluginRegistry.getPluginsBySection('sidebar')}
                        />
                    </section>

                    <section className="col-span-2">
                        <h2 className="text-xl font-semibold mb-3">Content Plugins</h2>
                        <PluginContainer 
                            section="content" 
                            plugins={pluginRegistry.getPluginsBySection('content')}
                        />
                    </section>
                </div>

                <section>
                    <h2 className="text-xl font-semibold mb-3">Footer Plugins</h2>
                    <PluginContainer 
                        section="footer" 
                        plugins={pluginRegistry.getPluginsBySection('footer')}
                    />
                </section>
            </div>

            {/* Plugin Settings Panel */}
            <div className="mt-8">
                <h2 className="text-xl font-semibold mb-4">Plugin Settings</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {Object.values(pluginRegistry.getPluginsBySection('content'))
                        .concat(pluginRegistry.getPluginsBySection('header'))
                        .concat(pluginRegistry.getPluginsBySection('sidebar'))
                        .concat(pluginRegistry.getPluginsBySection('footer'))
                        .map(plugin => (
                            <PluginSettings
                                key={plugin.id}
                                plugin={plugin}
                                onSettingsChange={(enabled, section) => {
                                    if (plugin.config) {
                                        plugin.config.enabled = enabled;
                                    }
                                    if (section) {
                                        plugin.section = section;
                                    }
                                }}
                            />
                        ))}
                </div>
            </div>
        </div>
    );
};