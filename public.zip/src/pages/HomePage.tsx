import React from 'react';
import { PluginContainer } from '../components/PluginContainer/PluginContainer';
import { pluginRegistry } from '../plugins/registry';

export const HomePage: React.FC = () => {
    return (
        <div className="page-container">
            <PluginContainer 
                section="header" 
                plugins={pluginRegistry.getPluginsBySection('header')} 
            />
            <div className="content-layout">
                <PluginContainer 
                    section="sidebar" 
                    plugins={pluginRegistry.getPluginsBySection('sidebar')} 
                />
                <PluginContainer 
                    section="content" 
                    plugins={pluginRegistry.getPluginsBySection('content')} 
                />
            </div>
            <PluginContainer 
                section="footer" 
                plugins={pluginRegistry.getPluginsBySection('footer')} 
            />
        </div>
    );
};