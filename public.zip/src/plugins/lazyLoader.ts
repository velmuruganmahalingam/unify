export const lazyLoadPlugin = async (pluginId: string) => {
    try {
        const plugin = await import(`./plugins/${pluginId}`);
        return plugin.default;
    } catch (error) {
        console.error(`Failed to load plugin ${pluginId}:`, error);
        throw error;
    }
};

export type LazyPlugin = Promise<React.ComponentType<any>>;