export interface PluginConfig {
    enabled: boolean;
    position?: string;
    settings?: Record<string, any>;
}

export const defaultConfig: PluginConfig = {
    enabled: true,
    position: 'left',
    settings: {}
};
