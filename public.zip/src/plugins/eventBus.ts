type EventHandler = (data: any) => void;

class PluginEventBus {
    private events: Map<string, EventHandler[]> = new Map();
    
    subscribe(event: string, handler: EventHandler) {
        if (!this.events.has(event)) {
            this.events.set(event, []);
        }
        this.events.get(event)?.push(handler);

        // Return unsubscribe function
        return () => {
            const handlers = this.events.get(event);
            if (handlers) {
                const index = handlers.indexOf(handler);
                if (index > -1) {
                    handlers.splice(index, 1);
                }
            }
        };
    }
    
    publish(event: string, data: any) {
        const handlers = this.events.get(event);
        if (handlers) {
            handlers.forEach(handler => {
                try {
                    handler(data);
                } catch (error) {
                    console.error(`Error in event handler for ${event}:`, error);
                }
            });
        }
    }

    // Clear all handlers for an event
    clear(event: string) {
        this.events.delete(event);
    }

    // Clear all events and handlers
    clearAll() {
        this.events.clear();
    }
}

// Create a singleton instance
export const pluginEventBus = new PluginEventBus();

// Export types for TypeScript support
export type { EventHandler };