import { PluginConfig } from './config';
import { PluginLifecycle } from './lifecycle';

export interface Plugin {
    id: string;
    name: string;
    description?: string;
    section: 'header' | 'sidebar' | 'content' | 'footer';
    component: React.ComponentType<any>;
    config?: PluginConfig;
    lifecycle?: PluginLifecycle;
    order?: number;
    dependencies?: string[];
}
