import { Plugin } from './types';

class PluginRegistry {
    private plugins: Map<string, Plugin> = new Map();
    private sections: Set<string> = new Set(['header', 'sidebar', 'content', 'footer']);

    register(plugin: Plugin): void {
        if (!this.sections.has(plugin.section)) {
            throw new Error(`Invalid section: ${plugin.section}`);
        }
        this.plugins.set(plugin.id, plugin);
    }

    unregister(pluginId: string): void {
        this.plugins.delete(pluginId);
    }

    getPlugin(pluginId: string): Plugin | undefined {
        return this.plugins.get(pluginId);
    }

    getPluginsBySection(section: string): Plugin[] {
        return Array.from(this.plugins.values())
            .filter(plugin => plugin.section === section);
    }
}

export const pluginRegistry = new PluginRegistry();