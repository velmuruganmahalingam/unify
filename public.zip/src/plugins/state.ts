export class PluginStateManager {
    static saveState(pluginId: string, state: any) {
        try {
            localStorage.setItem(`plugin_${pluginId}_state`, JSON.stringify(state));
        } catch (error) {
            console.error(`Failed to save state for plugin ${pluginId}:`, error);
        }
    }

    static loadState(pluginId: string) {
        try {
            const state = localStorage.getItem(`plugin_${pluginId}_state`);
            return state ? JSON.parse(state) : null;
        } catch (error) {
            console.error(`Failed to load state for plugin ${pluginId}:`, error);
            return null;
        }
    }

    static clearState(pluginId: string) {
        localStorage.removeItem(`plugin_${pluginId}_state`);
    }
}