export interface PluginLifecycle {
    onMount?: () => void;
    onUnmount?: () => void;
    onUpdate?: (prevProps: any) => void;
}