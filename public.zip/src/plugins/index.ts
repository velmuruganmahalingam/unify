import { pluginRegistry } from './registry';
import { DemoFormPlugin } from './examples/DemoFormPlugin';

pluginRegistry.register(DemoFormPlugin);