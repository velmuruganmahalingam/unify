import React, { useEffect, useState } from 'react';
import { Plugin } from './types';
import { pluginRegistry } from './registry';
import { pluginEventBus } from './eventBus';

interface PluginManagerProps {
    section: string;
}

export const PluginManager: React.FC<PluginManagerProps> = ({ section }) => {
    const [plugins, setPlugins] = useState<Plugin[]>([]);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        // Load plugins for the section
        const loadPlugins = () => {
            try {
                const sectionPlugins = pluginRegistry.getPluginsBySection(section);
                setPlugins(sectionPlugins);
                
                // Restore plugin states from localStorage
                sectionPlugins.forEach(plugin => {
                    const savedState = localStorage.getItem(`plugin_state_${plugin.id}`);
                    if (savedState) {
                        pluginEventBus.publish(`${plugin.id}:restore`, JSON.parse(savedState));
                    }
                });
            } catch (err) {
                setError(err instanceof Error ? err.message : 'Failed to load plugins');
            }
        };

        loadPlugins();

        // Subscribe to plugin state changes
        const unsubscribe = pluginEventBus.subscribe('plugin:stateChange', ({ pluginId, state }) => {
            localStorage.setItem(`plugin_state_${pluginId}`, JSON.stringify(state));
        });

        return () => {
            unsubscribe();
        };
    }, [section]);

    if (error) {
        return (
            <div className="p-4 bg-red-100 text-red-700 rounded">
                Error loading plugins: {error}
            </div>
        );
    }

    return (
        <div className="plugin-manager">
            {plugins.map(plugin => {
                const PluginComponent = plugin.component;
                return (
                    <div key={plugin.id} className="plugin-wrapper mb-4">
                        <ErrorBoundary>
                            <PluginComponent />
                        </ErrorBoundary>
                    </div>
                );
            })}
        </div>
    );
};

// Error Boundary Component
class ErrorBoundary extends React.Component<
    { children: React.ReactNode },
    { hasError: boolean }
> {
    constructor(props: { children: React.ReactNode }) {
        super(props);
        this.state = { hasError: false };
    }

    static getDerivedStateFromError() {
        return { hasError: true };
    }

    componentDidCatch(error: Error) {
        console.error('Plugin Error:', error);
    }

    render() {
        if (this.state.hasError) {
            return (
                <div className="p-4 bg-yellow-100 text-yellow-700 rounded">
                    Something went wrong with this plugin.
                </div>
            );
        }

        return this.props.children;
    }
}