import React from 'react';
import { Plugin } from '../types';
import UForm from '../../components/UForm/U-Form';
import type { Field } from '../../components/UForm/U-Form';

const DemoFormComponent: React.FC = () => {
    const fields: Field[] = [
        {
            name: 'example',
            label: 'Example Field',
            type: 'text'
        }
    ];

    const handleSubmit = (data: Record<string, any>) => {
        alert('Form submitted: ' + JSON.stringify(data));
    };

    const handleChange = (data: Record<string, any>) => {
        // This will be called on every change
        console.log('Form changed:', data);
        // You can add any real-time logic here
    };

    return (
        <div className="p-4">
            <h2>Demo Form Plugin</h2>
            <UForm
                fields={fields}
                onSubmit={handleSubmit}
                onChange={handleChange}
                layout="vertical"
            />
        </div>
    );
};

export const DemoFormPlugin: Plugin = {
    id: 'demo-form',
    name: 'Demo Form Plugin',
    description: 'A simple demo form plugin',
    section: 'content',
    component: DemoFormComponent,
    config: {
        enabled: true,
        position: 'top',
        settings: {}
    }
};