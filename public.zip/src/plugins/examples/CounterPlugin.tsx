import React, { useState, useEffect } from 'react';
import { Plugin } from '../types';
import { pluginEventBus } from '../eventBus';

const CounterComponent: React.FC = () => {
    const [count, setCount] = useState(0);

    useEffect(() => {
        // Lifecycle: Mount
        const savedCount = localStorage.getItem('counter_state');
        if (savedCount) {
            setCount(parseInt(savedCount, 10));
        }

        // Subscribe to events
        const unsubscribe = pluginEventBus.subscribe('counter:reset', () => {
            setCount(0);
        });

        return () => {
            // Lifecycle: Unmount
            localStorage.setItem('counter_state', count.toString());
            unsubscribe();
        };
    }, [count]);

    return (
        <div className="p-4 border rounded-lg shadow-sm">
            <h2 className="text-lg font-semibold mb-2">Counter Plugin</h2>
            <div className="flex items-center gap-4">
                <button 
                    onClick={() => setCount(prev => prev - 1)}
                    className="px-3 py-1 bg-red-500 text-white rounded"
                >
                    -
                </button>
                <span className="text-xl">{count}</span>
                <button 
                    onClick={() => setCount(prev => prev + 1)}
                    className="px-3 py-1 bg-green-500 text-white rounded"
                >
                    +
                </button>
            </div>
        </div>
    );
};

export const CounterPlugin: Plugin = {
    id: 'counter',
    name: 'Counter',
    description: 'A simple counter plugin',
    section: 'content',
    component: CounterComponent,
    config: {
        enabled: true,
        position: 'top',
        settings: {}
    },
    order: 1
};