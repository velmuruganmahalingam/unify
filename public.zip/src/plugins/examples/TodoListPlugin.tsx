import React, { useState } from 'react';
import { Plugin } from '../types';
import { pluginEventBus } from '../eventBus';

interface Todo {
    id: number;
    text: string;
    completed: boolean;
}

const TodoListComponent: React.FC = () => {
    const [todos, setTodos] = useState<Todo[]>([]);
    const [newTodo, setNewTodo] = useState('');

    const addTodo = () => {
        if (newTodo.trim()) {
            const todo = {
                id: Date.now(),
                text: newTodo,
                completed: false
            };
            setTodos([...todos, todo]);
            setNewTodo('');
            // Emit event when todo is added
            pluginEventBus.publish('todo:added', todo);
        }
    };

    const toggleTodo = (id: number) => {
        const updatedTodos = todos.map(todo => 
            todo.id === id ? { ...todo, completed: !todo.completed } : todo
        );
        setTodos(updatedTodos);
        // Emit event when todo is toggled
        pluginEventBus.publish('todo:toggled', id);
    };

    return (
        <div className="p-4 border rounded-lg shadow-sm">
            <h2 className="text-lg font-semibold mb-2">Todo List Plugin</h2>
            <div className="flex gap-2 mb-4">
                <input
                    type="text"
                    value={newTodo}
                    onChange={(e) => setNewTodo(e.target.value)}
                    className="flex-1 px-3 py-1 border rounded"
                    placeholder="Add new todo"
                    onKeyPress={(e) => e.key === 'Enter' && addTodo()}
                />
                <button 
                    onClick={addTodo}
                    className="px-4 py-1 bg-blue-500 text-white rounded"
                >
                    Add
                </button>
            </div>
            <ul className="space-y-2">
                {todos.map(todo => (
                    <li 
                        key={todo.id}
                        className="flex items-center gap-2"
                    >
                        <input
                            type="checkbox"
                            checked={todo.completed}
                            onChange={() => toggleTodo(todo.id)}
                        />
                        <span className={todo.completed ? 'line-through' : ''}>
                            {todo.text}
                        </span>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export const TodoListPlugin: Plugin = {
    id: 'todo-list',
    name: 'Todo List',
    description: 'A todo list plugin with event communication',
    section: 'content',
    component: TodoListComponent,
    config: {
        enabled: true,
        position: 'bottom',
        settings: {}
    },
    order: 2
};