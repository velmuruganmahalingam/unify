import React from 'react';
import { Plugin } from '../../plugins/types';

interface PluginContainerProps {
    section: string;
    plugins: Plugin[];
}

export const PluginContainer: React.FC<PluginContainerProps> = ({ section, plugins }) => {
    return (
        <div className="plugin-container" data-section={section}>
            {plugins.map(plugin => {
                const PluginComponent = plugin.component;
                return (
                    <div key={plugin.id} className="plugin-wrapper">
                        <PluginComponent {...plugin.config} />
                    </div>
                );
            })}
        </div>
    );
};