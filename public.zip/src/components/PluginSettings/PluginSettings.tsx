import React from 'react';
import { Plugin } from '../../plugins/types';

interface PluginSettingsProps {
    plugin: Plugin;
    onSettingsChange: (enabled: boolean, section?: 'header' | 'sidebar' | 'content' | 'footer') => void;
}

export const PluginSettings: React.FC<PluginSettingsProps> = ({ plugin, onSettingsChange }) => {
    return (
        <div className="p-4 border rounded">
            <h3 className="font-medium">{plugin.name}</h3>
            <div className="space-y-3">
                <label className="flex items-center">
                    <input
                        type="checkbox"
                        checked={plugin.config?.enabled}
                        onChange={(e) => onSettingsChange(e.target.checked)}
                        className="mr-2"
                    />
                    Enable Plugin
                </label>
                <div>
                    <label className="block text-sm">Section:</label>
                    <select 
                        value={plugin.section}
                        onChange={(e) => onSettingsChange(
                            plugin.config?.enabled || false, 
                            e.target.value as 'header' | 'sidebar' | 'content' | 'footer'
                        )}
                        className="mt-1 block w-full p-2 border rounded"
                    >
                        <option value="header">Header</option>
                        <option value="sidebar">Sidebar</option>
                        <option value="content">Content</option>
                        <option value="footer">Footer</option>
                    </select>
                </div>
            </div>
        </div>
    );
};